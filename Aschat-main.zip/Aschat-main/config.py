from os import getenv

from dotenv import load_dotenv

load_dotenv()

API_ID = "10046731"
# -------------------------------------------------------------
API_HASH = "09a25ea3e558df7e5d969c144b0452d9"
# --------------------------------------------------------------
BOT_TOKEN = getenv("BOT_TOKEN", None)
MONGO_URL = getenv("MONGO_URL", None)
OWNER_ID = getenv("OWNER_ID", "5981008313")
SUPPORT_GRP = "the_comedy_bar"
UPDATE_CHNL = "AS_Bots_Updates"
OWNER_USERNAME = "Oxygen_420"

